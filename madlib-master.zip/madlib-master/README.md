# madlib
javascrpit madlib for week 2
